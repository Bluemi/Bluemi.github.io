def get_pos():
    raise NotImplementedError('MousePosition depends on event handling')
