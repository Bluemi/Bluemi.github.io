import sys
import pygame as pg


DEFAULT_SCREEN_SIZE = (400, 400)


class Main:
    def __init__(self):
        pg.init()
        self.screen = pg.display.set_mode(DEFAULT_SCREEN_SIZE)
        self.running = True

    def handle_event(self, event):
        if event.type == pg.QUIT:
            self.running = False
        elif event.type == pg.KEYDOWN:
            if event.unicode == 'q':
                self.running = False
        elif event.type == pg.MOUSEBUTTONDOWN:
            print('mouse clicked')

    def handle_events(self, events):
        for event in events:
            self.handle_event(event)

        # render
        self.screen.fill(pg.Color(100, 100, 100))
        pg.draw.line(self.screen, pg.Color(255, 0, 0), (100, 100), pg.mouse.get_pos())
        pg.display.flip()


def main():
    main_instance = Main()
    if "pyodide" in sys.modules:
        pg.event.register_event_callback(main_instance.handle_events)
        return main_instance
    else:
        while main_instance.running:
            events = [pg.event.wait()] + pg.event.get()
            main_instance.handle_events(events)
        pg.quit()




if __name__ == '__main__':
    main()

