import pygame as pg
import random


DEFAULT_SCREEN_SIZE = (400, 400)


def main():
    pg.init()
    screen = pg.display.set_mode(DEFAULT_SCREEN_SIZE)

    # render
    screen.fill(pg.Color(100, 100, 100))
    pg.draw.line(screen, pg.Color(255, 0, 0), (100, 100), (200, random.randint(100, 200)))
    pg.display.flip()

    pg.quit()


if __name__ == '__main__':
    main()

