import sys
import random
import pygame as pg


DEFAULT_SCREEN_SIZE = (1200, 400)
NUM_LINES = 20


class Main:
    def __init__(self):
        pg.init()
        self.screen = pg.display.set_mode(DEFAULT_SCREEN_SIZE)
        self.running = True
        self.lines = [(100, 100)]

    def handle_event(self, event):
        if event.type == pg.QUIT:
            self.running = False
        elif event.type == pg.MOUSEWHEEL:
            print(event.y)
        elif event.type == pg.KEYDOWN:
            if event.unicode == 'q':
                self.running = False
        elif event.type == pg.MOUSEBUTTONDOWN and event.button == 1:
            self.lines.append((random.randint(0, 400), random.randint(0, 400)))
            print(len(self.lines))

    def handle_events(self, events):
        for event in events:
            self.handle_event(event)

        # render
        self.screen.fill(pg.Color(100, 100, 100))
        for line in self.lines:
            pg.draw.line(self.screen, pg.Color(255, 0, 0), line, pg.mouse.get_pos())
        pg.display.flip()


def main():
    main_instance = Main()
    if "pyodide" in sys.modules:
        pg.event.register_event_callback(main_instance.handle_events)
        return main_instance
    else:
        while main_instance.running:
            events = [pg.event.wait()] + pg.event.get()
            main_instance.handle_events(events)
        pg.quit()




if __name__ == '__main__':
    main()

