def main():
    print('Das ist mein Test')


if __name__ == '__main__':
    main()

