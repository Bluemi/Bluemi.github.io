mouse_position = (0, 0)


def get_pos():
    return mouse_position
