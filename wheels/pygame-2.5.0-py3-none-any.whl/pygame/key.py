def get_mods():
    return 0  # TODO